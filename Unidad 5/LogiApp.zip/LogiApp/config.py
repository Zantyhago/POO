# archivo de configuraciones

SQLALCHEMY_DATABASE_URI = 'sqlite:///datos.sqlite3'
SQLALCHEMY_TRACK_MODIFICATIONS = False
SECRET_KEY = 'clave_segura'