from classAudio import Audio
from classAudiovisual import Audiovisual
from classNodo import Nodo
import csv

class GestorAnuncio:
    __comienzo: Nodo
    __actual: Nodo
    __indice: int
    __tope: int

    def __init__(self):
        self.__comienzo = None
        self.__actual = None
        self.__indice = 0
        self.__tope = 0

    def getTope(self):
        return self.__tope
    
    def __iter__(self):
        return self
    
    def __next__(self):
        if self.__indice == self.__tope: 
            self.__actual = self.__comienzo
            self.__indice = 0 
            raise StopIteration 
        else:  
            self.__indice += 1  
            dato = self.__actual.getDato()
            self.__actual = self.__actual.getSiguiente() 
            return dato
    
    def agregaAnuncio(self, nuevoAnuncio):
        nodo = Nodo(nuevoAnuncio)
        if self.__comienzo is None:
            self.__comienzo = nodo
            self.__actual = nodo
        else:
            aux = self.__comienzo
            while aux.getSiguiente() is not None:
                aux = aux.getSiguiente()
            aux.getSiguiente()
        self.__tope += 1

    def leeDatos(self):
        try:
            archivo = open('anuncios.csv')
            reader = csv.reader(archivo, delimiter = ';')
            bandera = True            
            for fila in reader:
                if bandera:
                    bandera = False
                else:
                    if fila[0] == "AA":
                       self.agregaAnuncio(Audio(fila[1], fila[2], fila[3], float(fila[4]), fila[5], fila[6]))
                    elif fila[0] == "AV":
                        self.agregaAnuncio(Audiovisual(fila[1], fila[2], fila[3], float(fila[4]), fila[5], fila[6]))
        except FileNotFoundError as e:
            print(f"Archivo no encontrado. {e}")
        else:
            print("Se leyó el archivo 'anuncios.csv correctamente")
            archivo.close()

    def BuscaPorTitulo(self):
        xtitulo = input("Ingrese nombre del anuncio: ")
        aux = self.__comienzo
        i = 0
        bandera = False
        while i <= self.__tope and aux is not None:
            if isinstance(aux.getDato(), Audio):
                if aux.getDato().getTitulo() == xtitulo:
                        print(f"El tipo es Audio, su formato es {aux.getDato().getFormato()} y su canal es {aux.getDato().getCanal()}")
                        bandera = True
            if isinstance(aux.getDato(), Audiovisual):
                if aux.getDato().getTitulo() == xtitulo:
                        print(f"El tipo es Audiovisual, su formato es {aux.getDato().getFormato()} y su resolucion es {aux.getDato().getResolucion()}")
                        bandera = True 
            aux = aux.getSiguiente()
            i += 1
        
        if bandera is False:
            print(f"No hay anuncios con el titulo {xtitulo}.")

    def BuscaPorResolucion(self):
        xresolucion = input("Ingrese resolucion: ")
        aux = self.__comienzo
        i = 0
        badnera = True
        while i <= self.__tope and aux is not None:
            if isinstance(aux.getDato(), Audiovisual):
                if aux.getDato().getResolucion() == xresolucion:
                    print(f"{aux.getDato().getTitulo()} tiene esa resolucion.")
                    badnera = False
            aux = aux.getSiguiente()
            i += 1
        if badnera:
            print(f"No hay anuncios audiovisuales con la resolucion {xresolucion}.")

    def muestraAll(self):
        aux = self.__comienzo
        i = 0
        print(f"{self.__tope}")
        while i <= self.__tope:
            print(f"{aux.getDato()}")
            aux = aux.getSiguiente()
            i += 1