from classAnuncio import Anuncio

class Audio(Anuncio):
    __canalAudio: str
    
    def __init__(self, xtitulo, xduracion, xfecha, xcosto, xformato, xcanal):
        super().__init__(xtitulo, xduracion, xfecha, xcosto, xformato)
        self.__canalAudio  = xcanal

    def getCanal(self):
        return self.__canalAudio
    
    def getCostoTotal(self):
        costoBase = self.getCosto()
        duracion = float(self.getDuracion())
        tipo = self.getCanal()
        costo = costoBase * duracion
        if tipo == "surround":
            costoTotal = costo * 1.05
        elif tipo == "mono":
            costoTotal = costo * 1.01
        else:
            costoTotal = costo
        return costoTotal