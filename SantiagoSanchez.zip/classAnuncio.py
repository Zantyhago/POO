import abc

class Anuncio:
    __titulo: str
    __duracion: str
    __fechaCreac: str
    __costoPorSeg: float
    __formato: str

    def __init__(self, xtitulo, xduracion, xfecha, xcosto, xformato):
        self.__titulo = xtitulo
        self.__duracion = xduracion
        self.__fechaCreac = xfecha
        self.__costoPorSeg = xcosto
        self.__fechaCreac = xformato

    def getTitulo(self):
      return self.__titulo
    
    def getDuracion(self):
      return self.__duracion
    
    def getFecha(self):
      return self.__fechaCreac
    
    def getCosto(self):
      return self.__costoPorSeg
    
    def getFormato(self):
      return self.__formato
   
    @abc.abstractmethod
    def getCostoTotal(self):
       pass

    def __str__(self):
       return f"""
            Titulo : {self.getTitulo()}
            Duracion : {self.getDuracion()}
            Costo total. {self.getCostoTotal()}"""