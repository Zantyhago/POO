from classLista import GestorAnuncio

def menu():
    op = int(input("""
                        Menú de Opciones
        1) Mostrar información de un anuncio a través de su titulo.
        2) Mostrar titulos de anuncios en base a una resolucion.
        3) Mostrar informacion de todos los anuncios.
        0) Salir.
    Su opcion --> """))
    return op

if __name__ == '__main__':
    GA = GestorAnuncio()
    GA.leeDatos()
    try:
        opcion = menu()
        if opcion < 0 or opcion > 3:
            raise IndexError
        while opcion != 0:
            if opcion == 1:
                GA.BuscaPorTitulo()
            elif opcion == 2:
                GA.BuscaPorResolucion()
            elif opcion == 3:
                GA.muestraAll()
            opcion = menu()
    except IndexError:
        print("Opcion fuera de rango.")