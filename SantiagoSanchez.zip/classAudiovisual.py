from classAnuncio import Anuncio

class Audiovisual(Anuncio):
    __resolucion: str

    def __init__(self, xtitulo, xduracion, xfecha, xcosto, xformato, xresolucion):
        super().__init__(xtitulo, xduracion, xfecha, xcosto, xformato)
        self.__resolucion = xresolucion

    def getResolucion(self):
        return self.__resolucion
    
    def getCostoTotal(self):
        costoBase = self.getCosto()
        duracion = self.getDuracion()
        resolucion = self.getResolucion()
        costo = costoBase * duracion
        if resolucion == "1440p":
            costoTotal = costo * 1.015
        if resolucion == "1080p":
            costoTotal = costo * 1.01
        else:
            costoTotal = costo
        return costoTotal