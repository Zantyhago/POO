from classAnuncio import Anuncio

class Nodo:
    __anuncio: Anuncio
    __siguiente: object

    def __init__(self, xanuncio):
        self.__anuncio = xanuncio
        self.__siguiente = None
    
    def setSiguiente(self, xsiguiente):
        self.__siguiente = xsiguiente

    def getSiguiente(self):
        return self.__siguiente
    
    def getDato(self):
        return self.__anuncio